from turtle import Turtle


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.color('white')
        self.hideturtle()
        self.p1_score = 0
        self.p2_score = 0
        self.update_score()


    def update_score(self):
        self.clear()
        self.goto(-100, 250)  # Position for Player 1 score
        self.write(self.p1_score, align='center', font=('Courier', 24, 'normal'))
        self.goto(100, 250)  # Position for Player 2 score
        self.write(self.p2_score, align='center', font=('Courier', 24, 'normal'))

    def update_score_l(self):
        self.p1_score += 1
        self.update_score()  # Call update to refresh the scoreboard

    def update_score_r(self):
        self.p2_score += 1
        self.update_score()  # Call update to refresh the scoreboard