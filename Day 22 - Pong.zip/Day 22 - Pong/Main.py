from turtle import Turtle, Screen
from paddles import Paddle
from scoreboard import Scoreboard
from ball import Ball
import time

#initialize the screen and configure title/settings
screen = Screen()
screen.setup(width=800, height=600)
screen.bgcolor('black')
screen.title("Pong")
screen.listen()
screen.tracer(0)


#TODO paddles
    #listen for key inputs, wasd and arrows for each player
    #ai for singleplayer?
#TODO scoreboard
    #two turtles.write, one tracking each score
    #updates on goal scored, board state resets
#TODO dashed line down the center
    #send turtle to top, draw dashed line down the screen before gameplay. Can be done at runtime

#create a turtle to divide the board in half and set to the top of the screen
timmy = Turtle()
timmy.hideturtle()
timmy.speed("fastest")
timmy.penup()
timmy.goto(0, 615)
timmy.setheading(270)
timmy.color('white')
#create paddles and ball objects
paddle_l = Paddle((-350, 0))
paddle_r = Paddle((350, 0))
ball = Ball()

screen.onkey(paddle_r.paddle_up, "Up")
screen.onkey(paddle_r.paddle_down, "Down")

screen.onkey(paddle_l.paddle_up, "w")
screen.onkey(paddle_l.paddle_down, "s")
#while loop to draw the dashed line down the screen until timmy reaches -600y
while timmy.ycor() > -600:
    timmy.pendown()
    timmy.forward(20)
    timmy.penup()
    timmy.forward(20)

#create scoreboard for both players
score = Scoreboard()



is_game_on = True
#main game loop
while is_game_on:
    time.sleep(ball.move_speed)
    screen.update()
    ball.ball_move()
    #detect collision with the top and bottom wall
    if ball.ycor() > 280 or ball.ycor() < -280:
        ball.bounce()
    #detect collision with the left or right paddle
    if ball.distance(paddle_l) < 50 and ball.xcor() < -330:
        ball.paddle_bounce()
        # print("collision!")
    elif ball.distance(paddle_r) < 50 and ball.xcor() > 330:
        ball.paddle_bounce()
    #detect if either player scores
    if ball.xcor() > 350:
        score.update_score_l()
        ball.goto(0, 0)
        ball.move_speed = 0.1
    elif ball.xcor() < -350:
        score.update_score_r()
        ball.goto(0, 0)
        ball.move_speed = 0.1
    #win conditions for either player and printing who won
    if score.p1_score == 10:
        is_game_on = False
        timmy.penup()
        timmy.goto(-10, 0)
        timmy.setheading(0)
        timmy.write("Player 1 wins!", align="center", font=("Courier", 24, "normal"))
    elif score.p2_score == 10:
        is_game_on = False
        timmy.penup()
        timmy.goto(-10, 0)
        timmy.setheading(0)
        timmy.write("Player 2 wins!", align="center", font=("Courier", 24, "normal"))

    # print("This is the current tick speed")



#TODO screen refresh
#TODO ball
    #bouncing turtle. Angled shots?
#TODO break code into classes
    #paddles, ball, scoreboard
#TODO collision detection
#TODO create screen
#TODO create and move a paddle
#TODO create another paddle
#TODO create the ball and make it move
#TODO detect collision with wall and bounce
#TODO detect collision with paddle
#TODO detect when paddle misses
#TODO keep track of scores


screen.exitonclick()
