import turtle
import pandas


screen = turtle.Screen()
screen.title("U.S. States Game")
screen.bgpic("blank_states_img.gif")

# def get_cursor_coords(x, y):
#     print(x, y)
#
# turtle.onscreenclick(get_cursor_coords)



correct_guesses = []
data = pandas.read_csv("50_states.csv")
timmy = turtle.Turtle()
timmy.hideturtle()
timmy.penup()
all_states = data.state.to_list()
missed_states = []

while len(correct_guesses) < 50:
    answer = screen.textinput(title=f"{len(correct_guesses)}/50 State Names", prompt="Please name a US state: ")
    if answer.title() in all_states:
        correct_guesses.append(answer.title())
        coords = data[data.state == answer.title()]
        timmy.goto(coords.x.item(), coords.y.item())
        timmy.write(f"{answer.title()}")
        # print(correct_guesses)
    elif answer == "Exit":
        for states in all_states:
            if states not in correct_guesses:
                missed_states.append(states)
        break

new_data = pandas.DataFrame(missed_states)
new_data.to_csv("missed_states.csv")






# convert guess to title case
# check if guess is within the 50 states
# write correct guesses onto the map
# use a loop to allow the user to keep guessing
# record the correct guesses in a list
# keep track of the score