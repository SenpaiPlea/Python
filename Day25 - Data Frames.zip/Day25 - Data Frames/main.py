from turtledemo.colormixer import ColorTurtle

import pandas as pd
import csv

# with open("weather_data.csv") as data_file:
#     data = csv.reader(data_file)
#     temperatures = []
#     for row in data:
#         if row[1] != "temp":
#             temperatures.append(int(row[1]))
#     print(temperatures)

# data = pd.read_csv("weather_data.csv")
# print(data["temp"])
# temp_data = data["temp"].to_list()
# average_temp = sum(temp_data)/len(temp_data)
# print(average_temp)
# print(data["temp"].max())
# print(data[data.temp == data.temp.max()])

# monday = data[data.day == "Monday"]
# print(monday.temp * 1.8 + 32)


# build data into a new dataframe
# the table will just contain the fur color and the sum of each color
# logged under the primary fur column
data = pd.read_csv("2018_Central_Park_Squirrel_Census_-_Squirrel_Data.csv")
gray = sum(data["Primary Fur Color"] == "Gray")
black = sum(data["Primary Fur Color"] == "Black")
cinnamon = sum(data["Primary Fur Color"] == "Cinnamon")
data_dict = {
    "fur color": ["Gray", "Black", "Cinnamon"],
    "count": [gray, black, cinnamon]
}
final = pd.DataFrame(data_dict)
final.to_csv("squirrel count.csv")
new_frame = pd.read_csv("squirrel count.csv")
print(new_frame)
# create a csv called squirrel_count
# export the newly created dataframe into the csv