from turtle import Screen, Turtle
from player import Player
from car import Car
from level import Level
import time


#create the screen
screen = Screen()
screen.setup(width=600, height=600)
screen.bgcolor("white")
screen.tracer(0)
screen.listen()

#create the player and set them to the bottom of the screen
timmy = Player()
screen.onkey(timmy.move_up,"w")
#initialize cars
car = Car()
#initialize level counter
level = Level()

#main game loop
is_game_on = True
while is_game_on:
    time.sleep(level.move_speed)
    screen.update()
    car.create_car()
    car.move_cars()
    if timmy.ycor() >= 280:
        level.increase_level()
        print(level.move_speed)
        timmy.goto(0, -280)
    for single_car in car.cars:
        if single_car.distance(timmy)< 20:
            is_game_on = False
            game_over = Turtle()
            game_over.color("black")
            game_over.hideturtle()
            game_over.penup()
            game_over.goto(0, 0)
            # noinspection PyTypeChecker
            game_over.write("*Squish* Game over!", align="center", font=("Courier", 24))
            screen.exitonclick()

#TODO create project on expert difficulty(using only the demo of the game to recreate it from scratch)
#TODO 1. A turtle moves forwards when you press the "Up" key. It can only move forwards, not back, left or right.
#TODO 2. Cars are randomly generated along the y-axis and will move from the right edge of the screen to the left edge.
#TODO 3. When the turtle hits the top edge of the screen, it moves back to the original position and the player levels
# up. On the next level, the car speed increases.
#TODO 4. When the turtle collides with a car, it's game over and everything stops.


