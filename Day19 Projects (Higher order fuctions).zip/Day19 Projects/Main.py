import random
from turtle import Turtle, Screen

#Higher order functions
# timmy = Turtle()
# screen = Screen()
#
#
#
# def move_forwards():
#     timmy.forward(10)
#
# def move_backwards():
#     timmy.backward(10)
#
# def turn_left():
#     timmy.left(10)
#
# def turn_right():
#     timmy.right(10)
#
# def clear_screen():
#     timmy.clear()
#     timmy.penup()
#     timmy.home()
#     timmy.pendown()
#
#
# screen.listen()
# screen.onkey(key='w', fun=move_forwards)
# screen.onkey(key='s', fun=move_backwards)
# screen.onkey(key='a', fun=turn_left)
# screen.onkey(key='d', fun=turn_right)
# screen.onkey(key='c', fun=clear_screen)
#
# screen.exitonclick()


#Object state and instances
is_race_on = False
screen = Screen()
screen.setup(500,400)
user_bet = screen.textinput(title="Make your bet", prompt="Which turtle will win the race? Enter a color: ")

number_of_turtles = 7

# Create a dictionary to hold the turtles
turtles = {}

# Starting coordinates
start_x = -240
start_y = 190
spacing_y = screen.window_height()/number_of_turtles

#list of colors to assign to the turtles
colors = ["red","orange","yellow","green","blue","purple","violet"]

# Loop to create turtles with different names and move them to their starting positions
for i in range(1, number_of_turtles + 1):
    turtle_name = f"turtle_{i}"  # Generate a unique name
    turtles[turtle_name] = Turtle()  # Create a turtle and store it in the dictionary
    turtles[turtle_name].shape('turtle') # turns the turtles into the turtle shape
    turtles[turtle_name].penup()  # Lift the pen so no line is drawn while moving

    #assign colors to each turtle
    turtles[turtle_name].color(colors[i - 1])
    # Calculate the Y-coordinate for the turtle
    y_position = start_y - (i - 1) * spacing_y

    # Move the turtle to the calculated position
    turtles[turtle_name].goto(start_x, y_position)

if user_bet:
    is_race_on = True

while is_race_on:

    for turtle in turtles.values():
        if turtle.xcor() > 230:
            is_race_on = False
            winner = turtle.pencolor()
            if winner == user_bet:
                screen.textinput("You've won!", f"The {winner} turtle is the winning turtle.")
                # print(f"You've won! The {winner} turtle is the winning turtle.")
            else:
                screen.textinput("You've lost!", f"The {winner} turtle is the winning turtle.")
                # print(f"You've lost! The {winner} turtle is the winning turtle.")

        random_distance = random.randint(0, 10)
        turtle.forward(random_distance)



screen.exitonclick()
